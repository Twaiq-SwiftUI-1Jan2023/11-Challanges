import Foundation

// MARK: - Challenge 1
func add_five(arr: [String]) -> [String] {
    // write your code here
    var answer = arr
    if !answer.isEmpty {
        for i in 0..<answer.count {
            answer[i] = "\(answer[i])5"
        }
    }
    return answer
}
add_five(arr: [])
add_five(arr: ["code","c"])
add_five(arr: ["test","t"])
add_five(arr: ["null"])
add_five(arr: ["book", "pen","pencil"])

// MARK: - Challenge 2
func middle_char(word: String) -> String {
    // write your code here
    var answer = ""
    if word.count < 2 {
        answer = word
    } else {
        if word.count % 2 == 1 {
            let idx = word.index(word.startIndex, offsetBy: (word.count/2))
            answer = String(word[idx])
        } else {
            let idx1 = word.index(word.startIndex, offsetBy: (word.count/2)-1)
            let idx2 = word.index(word.startIndex, offsetBy: (word.count/2))
            answer = String("\(word[idx1])\(word[idx2])")
        }
    }
    return answer
}
middle_char(word: "x")
middle_char(word: "xx")
middle_char(word: "axc")
middle_char(word: "axxd")
middle_char(word: "abxde")
middle_char(word: "abxxef")


// MARK: - Challenge 3
func similarOrdered(word1: String, word2: String) -> String {
    // write your code here
    let unique1 = Array(Set(word1))
    let unique2 = Array(Set(word2))
    let str1 = unique1.sorted(by: { $0 < $1 })
    let str2 = unique2.sorted(by: { $0 < $1 })

    var arr: [Character] = []
    
    for i in 0..<str1.count {
        if str2.contains(str1[i]) {
            var idx1 = i
            var idx2 = str2.firstIndex(of: str1[i])!
            var tempArr: [Character] = []
            
            while (idx1 < str1.count) && (idx2 < str2.count) {
                if str1[idx1] == str2[idx2] {
                    tempArr.append(str1[idx1])
                } else {
                    break
                }
                idx1 += 1
                idx2 += 1
            }
            if tempArr.count > arr.count {
                arr = tempArr
            }
        }
    }
    
    var answer: String = "No matches found"
    if !arr.isEmpty {
        answer = ""
        for item in arr {
            answer += "\(item)"
        }
    }
    return answer
}

similarOrdered(word1: "washing", word2: "waiting")
similarOrdered(word1: "me", word2: "meet")
similarOrdered(word1: "Reem", word2: "Nouf")
similarOrdered(word1: "abcdefggghi", word2: "abcdefghirr")
