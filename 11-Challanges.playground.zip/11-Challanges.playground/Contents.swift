import UIKit

var greeting = "Hello, playground"


// First Challenge
func add5 (arr: [String]) -> [String]{
    if arr.isEmpty {
       return arr
    }
return arr.map{$0 + "5" }
        
}
//var first = add5(arr: [])
var first = add5(arr: ["Sarraa", "Khalil", "Almudayfir"])
print(first)



// Second Challenge
func returnMiddle (name: String)-> String {
    if name.count % 2 == 0 {
        let count = name.count
        let start = name.index(name.startIndex, offsetBy: (count-1)/2)
        let end = name.index(name.startIndex, offsetBy: (count+3)/2)
        return String(name[start..<end])
    }
    let count = name.count
    let start = name.index(name.startIndex, offsetBy: (count-1)/2)
    let end = name.index(name.startIndex, offsetBy: (count+2)/2)
    return String(name[start..<end])

}
let name1 = returnMiddle(name: "abcdefgh")
print(name1)

//Third Challenge
//!!
