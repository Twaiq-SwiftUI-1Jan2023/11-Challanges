
import SwiftUI

@main
struct LocalizationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
