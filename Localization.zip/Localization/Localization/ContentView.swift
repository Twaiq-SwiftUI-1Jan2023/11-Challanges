

import SwiftUI

struct ContentView: View {
    @State var username = ""
    @State var password = ""
    var body: some View {
        VStack {
          SubView(title: "Welcome")
            VStack(alignment: .leading){
                
                HStack {
                    Text("UserName :").font(.largeTitle)
                    
                }
                
                TextField("enter username", text: $username)
                
                    
                Text("Password :").font(.largeTitle)
                SecureField("enter password", text: $password)
            }
            Button("Click"){
                
            }
            
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environment(\.locale, .init(identifier: "ar"))
    }
}

struct SubView: View {
    var title : String
    var body: some View {
    //LocalizedStringKey(title)
        Text(LocalizedStringKey(title)).font(.largeTitle)
    }
}
